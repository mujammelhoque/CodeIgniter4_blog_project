<?php

namespace App\Controllers;

class Helloworld extends BaseController
{
	public function index(){
        echo "index function called";
    }
    public function test1()
	{
		echo "test 1 called";
	}
	public function test2(){
		echo "test 2 called";
	}
    public function test3()
	{
		//echo "test 3 called";
        return view("welcome_message");
	}
	public function test4(){
		return view("about_us");
	}
}